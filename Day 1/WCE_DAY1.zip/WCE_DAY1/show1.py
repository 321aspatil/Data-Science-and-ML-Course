# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

def show():                        # function definition
    print('Hello World')
    print('Welcome')
    print('Goodbye!!!')

